# Poker refresh
- [x] Refine playing cards, table surfaces, lobby and shared interface.
- [x] Rotate card design and color automatically for every hand; test the rule.
- [x] Disable email signup confirmations in hosted auth settings.
- [x] Verify the interface on desktop and mobile and play successive hands.

# Mobile tables and paid daily tournament
- [x] Make mobile cards larger and separate seats, board and player actions.
- [x] Enforce ₱200 tournament buy-in and one entry per Manila calendar day on the server.
- [x] Persist tournament gameplay and pay ₱200 to the player finishing 1st runner-up without trusting browser results.
- [x] Test entry limits, payment, prize eligibility, resume and mobile gameplay.

# Player chat and updated prizes
- [x] Add persistent player chat and ready-made banter to cash tables and tournament.
- [x] Pay champion ₱2,000 and preserve second-place ₱200 with atomic settlement.
- [x] Verify shared chat, controlled champion settlement with wallet read-back, and small-screen layout.

# Seat connection and missing images
- [ ] Correct Netlify forwarding to the current published app.
- [ ] Resolve AI photos from current client assets and keep HTML errors out of the buy-in form.
- [ ] Verify buy-in, logo and photos; explain any redeployment needed.
- [ ] Apply lovable-sql/0004_tournament_100_fee_and_prizes.sql via Lovable (₱100 entrance fee; ₱1,000 champion; ₱500/₱200/₱50 runner-up prizes).
