<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Gabay na tala

Nae-enjoy ng mga manlalaro ang mga round ng poker sa mesa tuwing gusto nilang maglaro

## Sukatan

Mga poker hand na nilaro hanggang may resulta bawat araw
