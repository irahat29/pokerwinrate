import arianaPhoto from '@/assets/bots/ariana.jpg';
import mateoPhoto from '@/assets/bots/mateo.jpg';
import kenjiPhoto from '@/assets/bots/kenji.jpg';
import sofiaPhoto from '@/assets/bots/sofia.jpg';
import dantePhoto from '@/assets/bots/dante.jpg';
import yunaPhoto from '@/assets/bots/yuna.jpg';
import leoPhoto from '@/assets/bots/leo.jpg';
import priyaPhoto from '@/assets/bots/priya.jpg';
import viktorPhoto from '@/assets/bots/viktor.jpg';
import meiPhoto from '@/assets/bots/mei.jpg';
import diegoPhoto from '@/assets/bots/diego.jpg';
import zaraPhoto from '@/assets/bots/zara.jpg';

/** The photo set that used to be for AI seats only. Players without an uploaded photo now use it instead of an emoji. */
export const PHOTO_POOL = [
  arianaPhoto, mateoPhoto, kenjiPhoto, sofiaPhoto, dantePhoto, yunaPhoto,
  leoPhoto, priyaPhoto, viktorPhoto, meiPhoto, diegoPhoto, zaraPhoto,
];

/** Stable photo for a player name: the same name always gets the same picture. */
export function fallbackPhoto(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  return PHOTO_POOL[hash % PHOTO_POOL.length]!;
}

/** The player's own uploaded photo if there is one, otherwise a photo from the pool (never an emoji). */
export function avatarOrFallback(avatarUrl: string | null | undefined, name: string): string {
  return avatarUrl || fallbackPhoto(name);
}
